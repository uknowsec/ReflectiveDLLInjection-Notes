package main

//#include "dllmain.h"
//#include "ReflectiveDll.h"
import "C"
