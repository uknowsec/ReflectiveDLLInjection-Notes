package main

import "C"

import (
	"fmt"
	"os"
	gsq "github.com/kballard/go-shellquote"
)



//export test
func test(arg string) {

	args, err := gsq.Split(arg)
	if err == nil {
		os.Args = args
		for i := 0; i < len(os.Args); i++ {
			fmt.Print(os.Args[i])
		}
	}
}

func main()  {

}
